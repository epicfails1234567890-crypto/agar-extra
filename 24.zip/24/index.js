app = require("express")()
net = require("http").createServer(app)
//app.use("/public", require("express").static(__dirname + "/public"))
net.listen(process.env.PORT || 3000, () => { console.log("Ready!") })

app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

// Guardamos la instancia de socket.io en la variable 'io'
const io = require("socket.io")(net, {})

let obj={}
const tamano_tablero = 512
let tamano_jugador = 32 // El mismo tamaño que usas para dibujar (fillRect, etc.)
let walkspeed = 4

io.on("connection", (socket) => {
  rx=tamano_tablero*Math.random()
  ry=tamano_tablero*Math.random()
  obj[socket.id]={type:"player",x:rx,y:ry}
  /*
  RELIQUIAS DEL SCRIPT:
  socket.on("msg", (e) => {
    // Usamos io.emit para que llegue a todos, incluido el remitente
    io.emit("msg", { data: e.data })
  })
  */
  socket.on("left", (e) => {
    if(e.pressed==true){
      obj[socket.id].x-=walkspeed
    }
    
  })
  socket.on("right", (e) => {
    if(e.pressed==true){
      obj[socket.id].x+=walkspeed
    }
  })
  socket.on("up", (e) => {
    if(e.pressed==true){
      obj[socket.id].y-=walkspeed
    }
    
  })
  socket.on("down", (e) => {
    if(e.pressed==true){
      obj[socket.id].y+=walkspeed
    }
  })
  socket.on("disconnect", () => {
    console.log("Jugador desconectado:", socket.id)
    delete obj[socket.id]
  })
})
/*
RELIQUIAS:
setInterval(()=>{
  //RELIQUIAS DEL SCRIPT: socket.emit("eval",{code:"console.log("+eval(x)+")"})
  io.emit("eval",{code:`
    ctx.clearRect(0,0,500,500)
  `})
  for(let i in obj){
    if(obj[i].type=="player"){
      io.emit("eval",{code:`
        ctx.fillStyle="rgb(0,255,0)"
        ctx.fillRect(`+eval(obj[i].x)+`,`+eval(obj[i].y)+`,32,32)
        ctx.lineWidth=5
        ctx.strokeStyle="rgb(0,127,0)"
        ctx.strokeRect(`+eval(obj[i].x)+`,`+eval(obj[i].y)+`,32,32)
      `})
    }
  }
},1000/60)
*/
/*
// ¡AFUERA del connection!
setInterval(() => {
    let code = "ctx.clearRect(0,0,500,500);\n"
    
    for(let i in obj){
        if(obj[i].type=="player"){
            code += `
                ctx.fillStyle="rgb(0,255,0)";
                ctx.fillRect(${obj[i].x},${obj[i].y},32,32);
                ctx.lineWidth=5;
                ctx.strokeStyle="rgb(0,127,0)";
                ctx.strokeRect(${obj[i].x},${obj[i].y},32,32);
            `
        }
    }
    io.emit("eval", { code: code }) // Enviamos TODO junto en un solo paquete
}, 1000/60)
*/

// ¡AFUERA del connection!
setInterval(() => {
    // 1. Límites
    for(let i in obj){
        if (obj[i].x < 0) obj[i].x = 0
        if (obj[i].y < 0) obj[i].y = 0
        // Usar tamano_tablero correcto. Si el canvas es 500, tamano_tablero debe ser 500.
        if (obj[i].x > 512) obj[i].x = 512
        if (obj[i].y > 512) obj[i].y = 512
    }

    // 2. Iterar sobre los sockets CORRECTAMENTE (Socket.io v4 usa Map)
    io.sockets.sockets.forEach((socket, socketId) => {
        let jugadorActual = obj[socketId]
        if(!jugadorActual) return // Equivalente a 'continue' en un forEach

        // 3. Cámara
        let offsetX = 256 - jugadorActual.x
        let offsetY = 256 - jugadorActual.y

        // 4. Dibujada:

        let code = "ctx.clearRect(0,0,512,512);\n"

        // Tablero (Cuadraditos)
        code += `
            ctx.lineWidth = 4
            ctx.strokeStyle = "rgb(200,200,200)"
            for(x=0;x<${tamano_tablero};x+=32){
              for(y=0;y<${tamano_tablero};y+=32){
                ctx.strokeRect(${offsetX} + x, ${offsetY} + y, 32, 32)
              }
            }
        `

        // Tablero (borde rojo)
        code += `
            ctx.lineWidth = 4
            ctx.strokeStyle = "rgb(255,0,0)"
            ctx.strokeRect(${offsetX}, ${offsetY}, 512, 512)
        `
        
        // Jugadores
        for(let i in obj){
            if(obj[i].type == "player"){
                let screenX = obj[i].x + offsetX
                let screenY = obj[i].y + offsetY
                let radio = 16 // 32 / 2
                let colorFill = (i === socketId) ? "rgb(0,255,0)" : "rgb(255,0,0)"
                let colorStroke = (i === socketId) ? "rgb(0,127,0)" : "rgb(127,0,0)"

                code += `
                    ctx.beginPath()
                    ctx.arc(${screenX}, ${screenY}, ${radio}, 0, Math.PI * 2)
                    ctx.fillStyle = "${colorFill}"
                    ctx.fill()
                    ctx.lineWidth = 5
                    ctx.strokeStyle = "${colorStroke}"
                    ctx.stroke()
                `
            }
        }

        socket.emit("eval", { code: code })
    })
}, 1000/60)